package kr.or.ddit.homework.home16;

public abstract class Stage {
	
	abstract public int game();
	abstract public int gameMoney(int a);
	
}
